/* ============================================================
   LIVE EVENT FACILITATOR CONSOLE — shared engine
   Session name, keyboard-shortcut navigation, a small session-label
   widget, and a reusable countdown timer used by several modules.
   No team/score tracking — every activity is a flat, facilitator-led
   walkthrough (brief the room, reveal, discuss, move on).
   ============================================================ */

const LiveEvent = (() => {
  const STORAGE_KEY = 'synergyLiveEventState_v2';
  const CARD_ORDER_KEY = 'synergyLiveEventCardOrder_v1';

  function defaultState() {
    return {
      sessionName: ''
    };
  }

  let state = load();

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      return {
        ...defaultState(),
        sessionName: typeof parsed.sessionName === 'string' ? parsed.sessionName : ''
      };
    } catch (e) {
      console.warn('LiveEvent: failed to load saved state, starting fresh.', e);
      return defaultState();
    }
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('LiveEvent: failed to persist state.', e);
    }
    document.dispatchEvent(new CustomEvent('liveevent:update', { detail: getState() }));
    renderSessionWidget();
  }

  function getState() {
    return { ...state };
  }

  function setSessionName(name) {
    state.sessionName = String(name || '').trim();
    persist();
  }

  function resetSession() {
    state = defaultState();
    try {
      localStorage.removeItem(CARD_ORDER_KEY);
    } catch (e) {
      // Storage unavailable — nothing to clean up.
    }
    persist();
  }

  // ---------------- Session-label widget (persistent corner) ----------------
  function renderSessionWidget() {
    const el = document.getElementById('scoreboardWidget');
    if (!el) return;
    const name = state.sessionName;
    if (!name) {
      el.classList.add('le-hidden');
      el.innerHTML = '';
      return;
    }
    el.classList.remove('le-hidden');
    el.innerHTML = `<div class="sw-dept" title="${escapeHtml(name)}">${escapeHtml(name)}</div>`;
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // ---------------- Keyboard navigation ----------------
  let keyHandlers = {};
  function onAction(map) {
    keyHandlers = map || {};
  }

  function isTypingTarget(el) {
    return el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
  }

  function resolveHome() {
    return document.body.dataset.home || 'index.html';
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  function initKeyboard() {
    document.addEventListener('keydown', (e) => {
      if (isTypingTarget(e.target)) return;

      switch (e.key) {
        case ' ':
        case 'Enter':
          e.preventDefault();
          (keyHandlers.advance || keyHandlers.next)?.();
          break;
        case 'r':
        case 'R':
          e.preventDefault();
          keyHandlers.reveal?.();
          break;
        case 'ArrowRight':
          e.preventDefault();
          (keyHandlers.next || keyHandlers.advance)?.();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          keyHandlers.prev?.();
          break;
        case 'ArrowUp':
          keyHandlers.up?.();
          break;
        case 'ArrowDown':
          keyHandlers.down?.();
          break;
        case 'Escape':
          if (keyHandlers.escape) {
            keyHandlers.escape();
          } else {
            window.location.href = resolveHome();
          }
          break;
        case 'f':
        case 'F':
          toggleFullscreen();
          break;
        default:
          break;
      }
    });
  }

  // ---------------- Shared countdown timer ----------------
  // createTimer(el, seconds, { onExpire, onTick }) -> { start, stop, reset, isRunning }
  function createTimer(el, totalSeconds, opts) {
    opts = opts || {};
    let remaining = totalSeconds;
    let intervalId = null;
    let expired = false;

    function render() {
      el.classList.remove('amber', 'red', 'expired');
      if (remaining <= 5 && remaining > 0) el.classList.add('red');
      else if (remaining <= 10 && remaining > 0) el.classList.add('amber');
      if (expired) el.classList.add('expired');
      const digits = el.querySelector('.lt-digits');
      if (digits) digits.textContent = String(Math.max(remaining, 0)).padStart(2, '0');
    }

    function beep() {
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.18, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
        osc.onended = () => ctx.close();
      } catch (e) {
        // Web Audio unavailable — silently skip the beep.
      }
    }

    function tick() {
      remaining -= 1;
      render();
      opts.onTick?.(remaining);
      if (remaining <= 0) {
        stop();
        expired = true;
        render();
        beep();
        opts.onExpire?.();
      }
    }

    function start() {
      stop();
      expired = false;
      render();
      intervalId = setInterval(tick, 1000);
    }

    function stop() {
      if (intervalId) clearInterval(intervalId);
      intervalId = null;
    }

    function reset(newSeconds) {
      stop();
      remaining = typeof newSeconds === 'number' ? newSeconds : totalSeconds;
      expired = false;
      render();
    }

    render();

    return {
      start,
      stop,
      reset,
      isRunning: () => intervalId !== null,
      remaining: () => remaining
    };
  }

  // ---------------- Session bootstrapping ----------------
  function initScoreboardWidget() {
    if (document.getElementById('scoreboardWidget')) {
      renderSessionWidget();
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_KEY) {
          state = load();
          renderSessionWidget();
        }
      });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    initScoreboardWidget();
    initKeyboard();
  });

  return {
    getState,
    setSessionName,
    resetSession,
    renderSessionWidget,
    onAction,
    createTimer,
    toggleFullscreen,
    escapeHtml
  };
})();
