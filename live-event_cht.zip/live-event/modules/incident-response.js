/* AI Social Engineering Challenge — Scenario-based decision tree.
   3 decision points in a vishing + email + deepfake attack chain.
   Space = start/next, 1/2/3 = choose option, → = next (after reveal). */
(function () {
  let scenario = null;
  let stage = -1; // -1 = intro, 0..2 = decision points, 3 = final
  let chosen = false;

  const els = {
    introScreen: document.getElementById('introScreen'),
    scenarioScreen: document.getElementById('scenarioScreen'),
    finalScreen: document.getElementById('finalScreen'),
    stepCounter: document.getElementById('stepCounter'),
    scenarioCard: document.getElementById('scenarioCard'),
    scenarioText: document.getElementById('scenarioText'),
    choicesContainer: document.getElementById('choicesContainer'),
    revealPanel: document.getElementById('revealPanel'),
    resultText: document.getElementById('resultText'),
    lessonText: document.getElementById('lessonText'),
    dots: document.getElementById('progressDots'),
    nextBtn: document.getElementById('nextBtn'),
    takeaways: document.getElementById('takeaways'),
  };

  function renderDots() {
    if (!scenario) return;
    const total = scenario.decisionPoints.length + 1; // +1 for final
    els.dots.innerHTML = Array.from({ length: total }, (_, i) => {
      let cls = 'dot';
      if (stage === -1) {
        cls = i === 0 ? 'dot current' : 'dot';
      } else if (i === stage) {
        cls = 'dot current';
      } else if (i < stage) {
        cls = 'dot done';
      }
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function renderIntro() {
    els.introScreen.classList.remove('le-hidden');
    els.scenarioScreen.classList.add('le-hidden');
    els.finalScreen.classList.add('le-hidden');
    renderDots();
  }

  function renderDecisionPoint() {
    const dp = scenario.decisionPoints[stage];
    if (!dp) return;

    els.introScreen.classList.add('le-hidden');
    els.scenarioScreen.classList.remove('le-hidden');
    els.finalScreen.classList.add('le-hidden');

    els.stepCounter.textContent = `Decision Point ${stage + 1} of ${scenario.decisionPoints.length}`;
    els.scenarioText.textContent = dp.situation;

    els.choicesContainer.innerHTML = dp.options.map((opt, i) => `
      <button class="le-btn lg choice-btn ${opt.correct ? 'correct-choice' : ''}" 
              type="button" 
              data-choice="${i}"
              data-correct="${opt.correct}">
        <span class="choice-letter">${String.fromCharCode(65 + i)}</span>
        <span class="choice-text">${LiveEvent.escapeHtml(opt.text)}</span>
      </button>
    `).join('');

    els.revealPanel.classList.remove('show');
    els.resultText.textContent = '';
    els.lessonText.textContent = '';
    els.nextBtn.disabled = true;
    chosen = false;

    // Attach click handlers
    els.choicesContainer.querySelectorAll('.choice-btn').forEach(btn => {
      btn.addEventListener('click', () => chooseChoice(parseInt(btn.dataset.choice, 10)));
    });

    renderDots();
  }

  function chooseChoice(choiceIdx) {
    if (chosen) return;
    chosen = true;

    const dp = scenario.decisionPoints[stage];
    const option = dp.options[choiceIdx];
    const isCorrect = option.correct;

    const buttons = els.choicesContainer.querySelectorAll('.choice-btn');
    buttons.forEach((btn, i) => {
      btn.disabled = true;
      if (i === choiceIdx) {
        btn.classList.add('chosen', isCorrect ? 'correct' : 'incorrect');
      } else if (dp.options[i].correct) {
        btn.classList.add('correct');
      } else {
        btn.classList.add('incorrect');
      }
    });

    els.resultText.innerHTML = isCorrect
      ? '<i class="fa-solid fa-check"></i> <strong>CORRECT</strong> — ' + option.text
      : '<i class="fa-solid fa-xmark"></i> <strong>INCORRECT</strong> — The best response: ' + dp.options.find(o => o.correct).text;
    els.resultText.className = 'se-result ' + (isCorrect ? 'correct' : 'incorrect');
    els.lessonText.textContent = option.explanation;
    els.revealPanel.classList.add('show');
    els.nextBtn.disabled = false;
  }

  function renderFinal() {
    els.introScreen.classList.add('le-hidden');
    els.scenarioScreen.classList.add('le-hidden');
    els.finalScreen.classList.remove('le-hidden');

    els.takeaways.innerHTML = scenario.takeaways.map(t => `
      <div class="se-takeaway">
        <i class="${t.icon}"></i>
        <div>
          <h4>${LiveEvent.escapeHtml(t.title)}</h4>
          <p>${LiveEvent.escapeHtml(t.detail)}</p>
        </div>
      </div>
    `).join('');

    renderDots();
  }

  function render() {
    if (stage === -1) {
      renderIntro();
    } else if (stage < 3) {
      renderDecisionPoint();
    } else {
      renderFinal();
    }
  }

  function advance() {
    if (stage === -1) {
      stage = 0;
    } else if (stage < 3) {
      if (!chosen) return;
      stage++;
    }
    render();
  }

  function back() {
    if (stage > 0) {
      stage--;
      chosen = false;
    } else if (stage === 0) {
      stage = -1;
    }
    render();
  }

  function skipToReveal() {
    if (stage >= 0 && stage < 3 && !chosen) {
      // Auto-select correct answer for demo
      const dp = scenario.decisionPoints[stage];
      const correctIdx = dp.options.findIndex(o => o.correct);
      chooseChoice(correctIdx);
    }
  }

  els.startBtn.addEventListener('click', () => { stage = 0; render(); });
  els.nextBtn.addEventListener('click', advance);

  LiveEvent.onAction({
    advance,
    next: advance,
    prev: back,
    reveal: skipToReveal
  });

  // Number keys 1/2/3 for choices
  document.addEventListener('keydown', (e) => {
    if (stage < 0 || stage >= 3 || chosen) return;
    const num = parseInt(e.key, 10);
    if (num >= 1 && num <= 3) {
      e.preventDefault();
      chooseChoice(num - 1);
    }
  });

  fetch('../content/incident-response.json')
    .then((r) => r.json())
    .then((data) => {
      scenario = data;
      render();
    })
    .catch((err) => {
      els.scenarioText.textContent = 'Failed to load content/incident-response.json';
      console.error(err);
    });
})();