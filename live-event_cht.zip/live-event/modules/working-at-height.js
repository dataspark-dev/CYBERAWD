/* Working at Height — image queue with facilitator-controlled reveal.
   Same mechanic as Fault Finding: step through a scenario, reveal the
   hazard on demand, award points for a correct ID and the bonus "why". */
(function () {
  let items = [];
  let index = 0;
  let revealed = false;
  let awardedId = false;
  let awardedBonus = false;

  const els = {
    counter: document.getElementById('itemCounter'),
    title: document.getElementById('itemTitle'),
    frame: document.getElementById('imageFrame'),
    image: document.getElementById('itemImage'),
    placeholderFlag: document.getElementById('placeholderFlag'),
    overlay: document.getElementById('revealOverlay'),
    whatWrong: document.getElementById('whatIsWrongText'),
    whySuspicious: document.getElementById('whyItsSuspiciousText'),
    dots: document.getElementById('progressDots'),
    revealBtn: document.getElementById('revealBtn'),
    awardIdBtn: document.getElementById('awardIdBtn'),
    awardBonusBtn: document.getElementById('awardBonusBtn'),
    nextBtn: document.getElementById('nextBtn')
  };

  function renderDots() {
    els.dots.innerHTML = items.map((_, i) => {
      const cls = i === index ? 'dot current' : (i < index ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function renderItem() {
    const item = items[index];
    if (!item) return;
    els.counter.textContent = `Item ${index + 1} of ${items.length}`;
    els.title.textContent = item.title;
    els.frame.classList.add('is-loading');
    els.image.onload = () => els.frame.classList.remove('is-loading');
    els.image.onerror = () => els.frame.classList.remove('is-loading');
    els.image.src = item.imagePath;
    els.image.alt = item.title;
    els.placeholderFlag.classList.toggle('le-hidden', !item.placeholder);
    els.whatWrong.textContent = item.whatIsWrong;
    els.whySuspicious.textContent = item.whyItsSuspicious;

    revealed = false;
    awardedId = false;
    awardedBonus = false;
    els.overlay.classList.remove('show');
    els.awardIdBtn.disabled = true;
    els.awardBonusBtn.disabled = true;
    renderDots();
  }

  function reveal() {
    if (revealed) return;
    revealed = true;
    els.overlay.classList.add('show');
    els.awardIdBtn.disabled = false;
    els.awardBonusBtn.disabled = false;
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= items.length) return;
    index = newIndex;
    renderItem();
  }

  function next() {
    if (index < items.length - 1) goTo(index + 1);
  }

  function prev() {
    if (index > 0) goTo(index - 1);
  }

  els.revealBtn.addEventListener('click', reveal);
  els.nextBtn.addEventListener('click', next);
  els.awardIdBtn.addEventListener('click', () => {
    if (awardedId) return;
    awardedId = true;
    els.awardIdBtn.disabled = true;
    LiveEvent.addModulePoints('workingAtHeight', 1);
  });
  els.awardBonusBtn.addEventListener('click', () => {
    if (awardedBonus) return;
    awardedBonus = true;
    els.awardBonusBtn.disabled = true;
    LiveEvent.addModulePoints('workingAtHeight', 1);
  });

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  fetch('../content/working-at-height.json')
    .then((r) => r.json())
    .then((data) => {
      items = data;
      renderItem();
    })
    .catch((err) => {
      els.title.textContent = 'Failed to load content/working-at-height.json';
      console.error(err);
    });
})();
