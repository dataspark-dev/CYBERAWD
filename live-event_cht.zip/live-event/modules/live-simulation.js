/* Deepfake & Voice Clone Challenge — AI media identification.
   4 challenges: deepfake video, fake badge/image, voice clone audio, AI phishing email.
   Space = next, R = reveal, ← = back. */
(function () {
  let data = null;
  let stage = 0; // 0..challenges.length-1 = challenge; challenges.length = reveal
  const stageEl = document.getElementById('stage');
  const dotsEl = document.getElementById('progressDots');
  let revealed = false;

  function esc(s) { return LiveEvent.escapeHtml(s); }

  function renderDots() {
    if (!dotsEl || !data) return;
    const total = data.challenges.length + 1;
    dotsEl.innerHTML = Array.from({ length: total }, (_, i) => {
      const cls = i === stage ? 'dot current' : (i < stage ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function maxStage() {
    return data ? data.challenges.length : 0;
  }

  function buildChallengeEl(challenge, idx) {
    const mediaHtml = (() => {
      switch (challenge.mediaType) {
        case 'video':
          return `
            <div class="ls-media-video">
              <video id="challengeVideo" controls preload="metadata" poster="${esc(challenge.poster || '')}">
                <source src="${esc(challenge.mediaUrl)}" type="video/mp4">
                Your browser does not support the video tag.
              </video>
            </div>`;
        case 'audio':
          return `
            <div class="ls-media-audio">
              <audio id="challengeAudio" controls preload="metadata">
                <source src="${esc(challenge.mediaUrl)}" type="audio/mpeg">
                Your browser does not support the audio element.
              </audio>
              <p class="ls-audio-note">Click play to hear the voice message</p>
            </div>`;
        case 'image':
        default:
          return `
            <div class="ls-media-image">
              <img src="${esc(challenge.mediaUrl)}" alt="${esc(challenge.title)}" />
            </div>`;
      }
    })();

    const revealHtml = revealed ? `
      <div class="ls-reveal-panel show">
        <div class="lr-flag">
          <i class="${challenge.reveal.icon}"></i>
          <h4>${esc(challenge.reveal.label)}</h4>
          <p>${esc(challenge.reveal.detail)}</p>
        </div>
      </div>` : '';

    return `
      <div class="ls-challenge">
        <div class="ls-challenge-header">
          <span class="ls-challenge-num">Challenge ${idx + 1} of ${data.challenges.length}</span>
          <h2 class="ls-challenge-title">${esc(challenge.title)}</h2>
          <p class="ls-challenge-prompt">${esc(challenge.prompt)}</p>
        </div>
        <div class="ls-media-container">${mediaHtml}</div>
        ${revealHtml}
      </div>
    `;
  }

  function renderReveal() {
    const r = data.finalReveal;
    const flagsHtml = r.redFlags.map((f) => `
      <div class="lr-flag">
        <i class="${f.icon}"></i>
        <h4>${esc(f.label)}</h4>
        <p>${esc(f.detail)}</p>
      </div>
    `).join('');
    stageEl.innerHTML = `
      <div class="ls-reveal">
        <div class="lr-title">${esc(r.title)}</div>
        <div class="lr-subtitle">${esc(r.subtitle)}</div>
        <div class="lr-flags">${flagsHtml}</div>
        <div class="lr-cta">${esc(r.callToAction)}</div>
        <div class="qz-final-actions">
          <a class="le-btn primary lg" href="../index.html"><i class="fa-solid fa-house"></i> Finish — Back to Console</a>
        </div>
      </div>
    `;
  }

  function render() {
    if (!data) return;

    if (stage < data.challenges.length) {
      const challenge = data.challenges[stage];
      stageEl.innerHTML = buildChallengeEl(challenge, stage);
      revealed = false;
    } else {
      renderReveal();
    }
    renderDots();
  }

  function advance() {
    if (stage < data.challenges.length && !revealed) {
      revealed = true;
    } else {
      stage = Math.min(stage + 1, maxStage());
      revealed = false;
    }
    render();
  }

  function back() {
    stage = Math.max(stage - 1, 0);
    revealed = false;
    render();
  }

  function skipToReveal() {
    if (stage < data.challenges.length) {
      revealed = true;
      render();
    }
  }

  LiveEvent.onAction({
    advance,
    next: advance,
    prev: back,
    reveal: skipToReveal
  });

  // Pause media when leaving stage
  function pauseAllMedia() {
    const video = stageEl.querySelector('video');
    const audio = stageEl.querySelector('audio');
    if (video) video.pause();
    if (audio) audio.pause();
  }

  // Override advance/back to pause media
  const originalAdvance = advance;
  advance = function() {
    pauseAllMedia();
    originalAdvance();
  };
  const originalBack = back;
  back = function() {
    pauseAllMedia();
    originalBack();
  };

  fetch('../content/live-simulation.json')
    .then((r) => r.json())
    .then((json) => {
      data = json;
      render();
    })
    .catch((err) => {
      stageEl.innerHTML = '<p style="color:#fff;">Failed to load content/live-simulation.json</p>';
      console.error(err);
    });
})();