/* Fault Finding — real-vs-template comparison drill.
   Full-screen compare view. Space/Enter = reveal answer, ArrowRight/Space = next item, ArrowLeft = previous item. */
(function () {
  let categories = [];
  let items = [];
  let index = 0;
  let revealed = false;

  const els = {
    roundScreen: document.getElementById('roundScreen'),
    categoryTag: document.getElementById('categoryTag'),
    title: document.getElementById('itemTitle'),
    comparePanelA: document.getElementById('comparePanelA'),
    comparePanelB: document.getElementById('comparePanelB'),
    compareImageA: document.getElementById('compareImageA'),
    compareImageB: document.getElementById('compareImageB'),
    compareReveal: document.getElementById('compareRevealPanel'),
    compareWhatWrong: document.getElementById('compareWhatIsWrongText'),
    compareWhySuspicious: document.getElementById('compareWhyItsSuspiciousText'),
  };

  let fakeSide = 'A';

  function renderItem() {
    const item = items[index];
    if (!item) return;
    els.categoryTag.textContent = item.category || '';
    els.title.textContent = item.title;

    fakeSide = Math.random() < 0.5 ? 'A' : 'B';
    const realImg = fakeSide === 'A' ? els.compareImageB : els.compareImageA;
    const fakeImg = fakeSide === 'A' ? els.compareImageA : els.compareImageB;
    realImg.src = item.realImage;
    fakeImg.src = item.fakeImage;

    [els.comparePanelA, els.comparePanelB].forEach((p) => p.classList.remove('reveal-fake', 'reveal-real'));
    els.compareWhatWrong.textContent = item.whatIsWrong;
    els.compareWhySuspicious.textContent = item.whyItsSuspicious;
    els.compareReveal.classList.remove('show');

    revealed = false;
  }

  function reveal() {
    if (revealed) return;
    revealed = true;

    const fakePanel = fakeSide === 'A' ? els.comparePanelA : els.comparePanelB;
    const realPanel = fakeSide === 'A' ? els.comparePanelB : els.comparePanelA;
    fakePanel.classList.add('reveal-fake');
    realPanel.classList.add('reveal-real');
    els.compareReveal.classList.add('show');
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= items.length) return;
    index = newIndex;
    renderItem();
  }

  function next() {
    if (index < items.length - 1) { goTo(index + 1); return; }
    window.location.href = '../index.html';
  }

  function prev() {
    if (index > 0) goTo(index - 1);
  }

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  fetch('../content/fault-finding.json')
    .then((r) => r.json())
    .then((data) => {
      categories = data.categories || [];
      items = data.items || [];
      renderItem();
    })
    .catch((err) => {
      els.title.textContent = 'Failed to load content/fault-finding.json';
      console.error(err);
    });
})();