/* Strong Password Selection — draggable letter tiles + 30s timer.
   Tiles can be dragged into a new order at any time; each tile lights up
   green live as soon as it lands in its correct position. On reveal, a
   short strength-analysis tip explains why that term matters for building
   a strong password. Facilitator-led, no scoring. */
(function () {
  const TIMER_SECONDS = 30;
  let phrases = [];
  let index = 0;
  let revealed = false;
  let solved = false;
  let timer = null;
  let tileLetters = []; // current, user-reorderable arrangement for this phrase
  let correctLetters = []; // target arrangement (answer, spaces stripped)
  let draggedTileIdx = null;

  const els = {
    counter: document.getElementById('itemCounter'),
    tiles: document.getElementById('tilesContainer'),
    answerReveal: document.getElementById('answerReveal'),
    tipReveal: document.getElementById('tipReveal'),
    timerEl: document.getElementById('timer'),
    revealBtn: document.getElementById('revealBtn'),
    solvedBtn: document.getElementById('solvedBtn'),
    nextBtn: document.getElementById('nextBtn'),
    dots: document.getElementById('progressDots')
  };

  function renderDots() {
    els.dots.innerHTML = phrases.map((_, i) => {
      const cls = i === index ? 'dot current' : (i < index ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function buildCorrectLetters(p) {
    const compact = p.compactAnswer || p.answer.replace(/\s+/g, '');
    return compact.toUpperCase().split('');
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function renderTiles() {
    els.tiles.innerHTML = '';
    let allCorrect = tileLetters.length > 0;

    tileLetters.forEach((letter, i) => {
      const tile = document.createElement('div');
      tile.className = 'pp-tile';
      tile.textContent = letter;
      tile.draggable = true;
      tile.dataset.idx = String(i);

      const isCorrect = correctLetters[i] === letter;
      if (isCorrect) tile.classList.add('correct');
      else allCorrect = false;

      tile.addEventListener('dragstart', () => {
        draggedTileIdx = i;
        tile.classList.add('dragging');
      });
      tile.addEventListener('dragend', () => {
        tile.classList.remove('dragging');
        Array.from(els.tiles.children).forEach((t) => t.classList.remove('drag-over'));
        draggedTileIdx = null;
      });
      tile.addEventListener('dragover', (e) => {
        e.preventDefault();
        if (draggedTileIdx === null || draggedTileIdx === i) return;
        tile.classList.add('drag-over');
      });
      tile.addEventListener('dragleave', () => tile.classList.remove('drag-over'));
      tile.addEventListener('drop', (e) => {
        e.preventDefault();
        tile.classList.remove('drag-over');
        if (draggedTileIdx === null || draggedTileIdx === i) return;
        const moved = tileLetters.splice(draggedTileIdx, 1)[0];
        tileLetters.splice(i, 0, moved);
        renderTiles();
      });

      els.tiles.appendChild(tile);
    });

    els.tiles.classList.toggle('all-correct', allCorrect);
  }

  function renderPhrase() {
    const p = phrases[index];
    if (!p) return;
    els.counter.textContent = `Phrase ${index + 1} of ${phrases.length}`;

    correctLetters = buildCorrectLetters(p);
    // Shuffle until it's not already solved outright (rare, but possible
    // with very short phrases) so there's always something to reorder.
    let shuffled = shuffle(correctLetters);
    let attempts = 0;
    while (shuffled.join('') === correctLetters.join('') && attempts < 5) {
      shuffled = shuffle(correctLetters);
      attempts += 1;
    }
    tileLetters = shuffled;
    renderTiles();

    els.answerReveal.textContent = p.answer;
    els.answerReveal.classList.remove('show');
    els.tipReveal.textContent = p.tip || '';
    els.tipReveal.classList.remove('show');

    const isLast = index === phrases.length - 1;
    els.nextBtn.innerHTML = isLast
      ? '<i class="fa-solid fa-house"></i> Finish — Back to Console'
      : '<i class="fa-solid fa-forward"></i> Next Phrase';

    revealed = false;
    solved = false;
    els.solvedBtn.disabled = true;

    if (timer) timer.stop();
    timer = LiveEvent.createTimer(els.timerEl, TIMER_SECONDS, {
      onExpire: () => {
        els.solvedBtn.disabled = true;
      }
    });
    timer.start();
    els.solvedBtn.disabled = false;
    renderDots();
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= phrases.length) return;
    index = newIndex;
    renderPhrase();
  }

  function next() {
    if (index < phrases.length - 1) { goTo(index + 1); return; }
    window.location.href = '../index.html';
  }
  function prev() {
    if (index > 0) goTo(index - 1);
  }

  function reveal() {
    if (revealed) return;
    revealed = true;
    if (timer) timer.stop();
    els.answerReveal.classList.add('show');
    els.tipReveal.classList.add('show');
    els.solvedBtn.disabled = true;
  }

  function markSolved() {
    if (solved || els.solvedBtn.disabled) return;
    solved = true;
    els.solvedBtn.disabled = true;
    reveal();
  }

  els.revealBtn.addEventListener('click', reveal);
  els.solvedBtn.addEventListener('click', markSolved);
  els.nextBtn.addEventListener('click', next);

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  fetch('../content/pass-phrase.json')
    .then((r) => r.json())
    .then((data) => {
      phrases = data;
      renderPhrase();
    })
    .catch((err) => {
      els.tiles.textContent = 'FAILED TO LOAD CONTENT';
      console.error(err);
    });
})();
