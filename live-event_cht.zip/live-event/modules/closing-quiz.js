/* Closing Knowledge Check — 5-question quiz -> STOP-VERIFY-REPORT recap -> closing recap screen. */
(function () {
  let data = null;
  let phase = 'quiz'; // 'quiz' | 'svr' | 'final'
  let qIndex = 0;
  let sIndex = 0;
  let revealed = false;

  const stageEl = document.getElementById('stage');
  const phaseLabel = document.getElementById('phaseLabel');

  function letterFor(i) {
    return String.fromCharCode(65 + i);
  }

  function renderQuiz() {
    const q = data.questions[qIndex];
    phaseLabel.textContent = `Question ${qIndex + 1} of ${data.questions.length}`;
    const choicesHtml = q.choices.map((choice, i) => {
      const isCorrect = revealed && i === q.correctIndex;
      return `<div class="qz-choice ${isCorrect ? 'correct' : ''}">
        <span class="qz-letter">${letterFor(i)}</span>
        <span>${LiveEvent.escapeHtml(choice)}</span>
      </div>`;
    }).join('');

    stageEl.innerHTML = `
      <div class="qz-cluster-tag">${LiveEvent.escapeHtml(q.clusterLabel)}</div>
      <div class="qz-question">${LiveEvent.escapeHtml(q.question)}</div>
      <div class="qz-choices">${choicesHtml}</div>
      <div class="qz-explanation ${revealed ? 'show' : ''}">${LiveEvent.escapeHtml(q.explanation)}</div>
      <div class="le-btn-row" style="margin-top:26px;">
        <button class="le-btn amber lg" id="revealBtn" type="button" ${revealed ? 'disabled' : ''}><i class="fa-solid fa-eye"></i> Reveal Answer (R)</button>
        <button class="le-btn primary lg" id="nextBtn" type="button"><i class="fa-solid fa-forward"></i> ${qIndex < data.questions.length - 1 ? 'Next Question' : 'Continue to Recap'}</button>
      </div>
      <div class="le-progress-dots">${data.questions.map((_, i) => `<span class="dot ${i === qIndex ? 'current' : (i < qIndex ? 'done' : '')}"></span>`).join('')}</div>
    `;
    document.getElementById('revealBtn').addEventListener('click', revealQuiz);
    document.getElementById('nextBtn').addEventListener('click', nextQuiz);
  }

  function revealQuiz() {
    if (revealed) return;
    revealed = true;
    renderQuiz();
  }
  function nextQuiz() {
    if (qIndex < data.questions.length - 1) {
      qIndex += 1;
      revealed = false;
      renderQuiz();
    } else {
      phase = 'svr';
      sIndex = 0;
      revealed = false;
      renderSvr();
    }
  }
  function prevQuiz() {
    if (qIndex > 0) {
      qIndex -= 1;
      revealed = false;
      renderQuiz();
    }
  }

  function renderSvr() {
    const s = data.stopVerifyReportPrompts[sIndex];
    phaseLabel.textContent = `STOP → VERIFY → REPORT · Prompt ${sIndex + 1} of ${data.stopVerifyReportPrompts.length}`;
    stageEl.innerHTML = `
      <div class="qz-cluster-tag">Call &amp; Response</div>
      <div class="svr-scenario-card">
        <div class="svr-scenario-text">${LiveEvent.escapeHtml(s.scenario)}</div>
        <div class="svr-response ${revealed ? 'show' : ''}">${LiveEvent.escapeHtml(s.idealResponse)}</div>
      </div>
      <div class="le-btn-row" style="margin-top:26px;">
        <button class="le-btn amber lg" id="revealBtn" type="button"><i class="fa-solid fa-eye"></i> Reveal Ideal Response (R)</button>
        <button class="le-btn primary lg" id="nextBtn" type="button"><i class="fa-solid fa-forward"></i> ${sIndex < data.stopVerifyReportPrompts.length - 1 ? 'Next Prompt' : 'Final Scoreboard'}</button>
      </div>
      <div class="le-progress-dots">${data.stopVerifyReportPrompts.map((_, i) => `<span class="dot ${i === sIndex ? 'current' : (i < sIndex ? 'done' : '')}"></span>`).join('')}</div>
    `;
    document.getElementById('revealBtn').addEventListener('click', revealSvr);
    document.getElementById('nextBtn').addEventListener('click', nextSvr);
  }
  function revealSvr() {
    revealed = true;
    renderSvr();
  }
  function nextSvr() {
    if (sIndex < data.stopVerifyReportPrompts.length - 1) {
      sIndex += 1;
      revealed = false;
      renderSvr();
    } else {
      phase = 'final';
      renderFinal();
    }
  }
  function prevSvr() {
    if (sIndex > 0) {
      sIndex -= 1;
      revealed = false;
      renderSvr();
    } else {
      phase = 'quiz';
      qIndex = data.questions.length - 1;
      revealed = true;
      renderQuiz();
    }
  }

  function renderFinal() {
    phaseLabel.textContent = 'Closing Recap';
    stageEl.innerHTML = `
      <div class="qz-final-recap">
        <div class="fr-icon"><i class="fa-solid fa-shield-halved"></i></div>
        <div class="fr-eyebrow">Session Complete</div>
        <h1>Thanks for Taking Part</h1>
        <p>You've now practiced spotting a fake, walked through a live attack chain, and recapped the habits that stop them.</p>
        <div class="fr-cta">STOP → VERIFY → REPORT</div>
        <p>Carry those three words back to your desk — they're the single habit that matters most.</p>
      </div>
      <div class="qz-final-actions">
        <a class="le-btn primary lg" href="../index.html"><i class="fa-solid fa-house"></i> Return to Console</a>
      </div>
    `;
  }

  function render() {
    if (phase === 'quiz') renderQuiz();
    else if (phase === 'svr') renderSvr();
    else renderFinal();
  }

  function advance() {
    if (phase === 'quiz') nextQuiz();
    else if (phase === 'svr') nextSvr();
  }
  function prev() {
    if (phase === 'quiz') prevQuiz();
    else if (phase === 'svr') prevSvr();
    else { phase = 'svr'; sIndex = data.stopVerifyReportPrompts.length - 1; revealed = true; renderSvr(); }
  }
  function reveal() {
    if (phase === 'quiz') revealQuiz();
    else if (phase === 'svr') revealSvr();
  }

  LiveEvent.onAction({ advance, next: advance, prev, reveal });

  fetch('../content/closing-quiz.json')
    .then((r) => r.json())
    .then((json) => {
      data = json;
      render();
    })
    .catch((err) => {
      stageEl.innerHTML = '<p style="color:#fff;">Failed to load content/closing-quiz.json</p>';
      console.error(err);
    });
})();
