/* Cyber Clue Quest — riddle + 30s timer, facilitator-led reveal. The room
   calls out the answer together before time runs out; no team scoring. */
(function () {
  const TIMER_SECONDS = 30;
  let riddles = [];
  let index = 0;
  let revealed = false;
  let timer = null;

  const els = {
    counter: document.getElementById('itemCounter'),
    riddleText: document.getElementById('riddleText'),
    answerReveal: document.getElementById('answerReveal'),
    timerEl: document.getElementById('timer'),
    revealBtn: document.getElementById('revealBtn'),
    nextBtn: document.getElementById('nextBtn'),
    dots: document.getElementById('progressDots')
  };

  function renderDots() {
    els.dots.innerHTML = riddles.map((_, i) => {
      const cls = i === index ? 'dot current' : (i < index ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function renderRiddle() {
    const r = riddles[index];
    if (!r) return;
    els.counter.textContent = `Riddle ${index + 1} of ${riddles.length}`;
    els.riddleText.textContent = r.riddle;
    els.answerReveal.textContent = r.answer;
    els.answerReveal.classList.remove('show');

    const isLast = index === riddles.length - 1;
    els.nextBtn.innerHTML = isLast
      ? '<i class="fa-solid fa-house"></i> Finish — Back to Console'
      : '<i class="fa-solid fa-forward"></i> Next Riddle';

    revealed = false;

    if (timer) timer.stop();
    timer = LiveEvent.createTimer(els.timerEl, TIMER_SECONDS, {});
    timer.start();
    renderDots();
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= riddles.length) return;
    index = newIndex;
    renderRiddle();
  }

  function next() {
    if (index < riddles.length - 1) { goTo(index + 1); return; }
    window.location.href = '../index.html';
  }
  function prev() {
    if (index > 0) goTo(index - 1);
  }

  function reveal() {
    if (revealed) return;
    revealed = true;
    if (timer) timer.stop();
    els.answerReveal.classList.add('show');
  }

  els.revealBtn.addEventListener('click', reveal);
  els.nextBtn.addEventListener('click', next);

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  fetch('../content/clue-quest.json')
    .then((r) => r.json())
    .then((data) => {
      riddles = data;
      renderRiddle();
    })
    .catch((err) => {
      els.riddleText.textContent = 'Failed to load content/clue-quest.json';
      console.error(err);
    });
})();
