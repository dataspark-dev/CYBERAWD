/* Pass-Phrase — scrambled phrase + 30s timer. 1 point if solved in time, no partial credit. */
(function () {
  const TIMER_SECONDS = 30;
  let phrases = [];
  let index = 0;
  let revealed = false;
  let solved = false;
  let timer = null;

  const els = {
    counter: document.getElementById('itemCounter'),
    scrambleText: document.getElementById('scrambleText'),
    answerReveal: document.getElementById('answerReveal'),
    timerEl: document.getElementById('timer'),
    revealBtn: document.getElementById('revealBtn'),
    solvedBtn: document.getElementById('solvedBtn'),
    nextBtn: document.getElementById('nextBtn'),
    dots: document.getElementById('progressDots')
  };

  function renderDots() {
    els.dots.innerHTML = phrases.map((_, i) => {
      const cls = i === index ? 'dot current' : (i < index ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function renderPhrase() {
    const p = phrases[index];
    if (!p) return;
    els.counter.textContent = `Phrase ${index + 1} of ${phrases.length}`;
    els.scrambleText.textContent = p.scrambled;
    els.answerReveal.textContent = p.answer;
    els.answerReveal.classList.remove('show');

    revealed = false;
    solved = false;
    els.solvedBtn.disabled = true;

    if (timer) timer.stop();
    timer = LiveEvent.createTimer(els.timerEl, TIMER_SECONDS, {
      onExpire: () => {
        els.solvedBtn.disabled = true;
      }
    });
    timer.start();
    els.solvedBtn.disabled = false;
    renderDots();
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= phrases.length) return;
    index = newIndex;
    renderPhrase();
  }

  function next() {
    if (index < phrases.length - 1) goTo(index + 1);
  }
  function prev() {
    if (index > 0) goTo(index - 1);
  }

  function reveal() {
    if (revealed) return;
    revealed = true;
    if (timer) timer.stop();
    els.answerReveal.classList.add('show');
    els.solvedBtn.disabled = true;
  }

  function markSolved() {
    if (solved || els.solvedBtn.disabled) return;
    solved = true;
    els.solvedBtn.disabled = true;
    LiveEvent.addModulePoints('passPhrase', 1);
    reveal();
  }

  els.revealBtn.addEventListener('click', reveal);
  els.solvedBtn.addEventListener('click', markSolved);
  els.nextBtn.addEventListener('click', next);

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  fetch('../content/pass-phrase.json')
    .then((r) => r.json())
    .then((data) => {
      phrases = data;
      renderPhrase();
    })
    .catch((err) => {
      els.scrambleText.textContent = 'FAILED TO LOAD CONTENT';
      console.error(err);
    });
})();
