/* Cyber Clue Quest — riddle + 30s timer + Team A / Team B buzz-in scoring. */
(function () {
  const TIMER_SECONDS = 30;
  let riddles = [];
  let index = 0;
  let revealed = false;
  let lockedTeam = null; // 'A' | 'B' | null
  let timer = null;

  const els = {
    counter: document.getElementById('itemCounter'),
    riddleText: document.getElementById('riddleText'),
    answerReveal: document.getElementById('answerReveal'),
    timerEl: document.getElementById('timer'),
    teamABtn: document.getElementById('teamABtn'),
    teamBBtn: document.getElementById('teamBBtn'),
    teamAScore: document.getElementById('teamAScore'),
    teamBScore: document.getElementById('teamBScore'),
    revealBtn: document.getElementById('revealBtn'),
    nextBtn: document.getElementById('nextBtn'),
    dots: document.getElementById('progressDots')
  };

  function syncTeamScores() {
    const s = LiveEvent.getState();
    els.teamAScore.textContent = s.teams.A.points;
    els.teamBScore.textContent = s.teams.B.points;
    document.getElementById('teamALabel').textContent = s.teams.A.label.toUpperCase();
    document.getElementById('teamBLabel').textContent = s.teams.B.label.toUpperCase();
  }
  document.addEventListener('liveevent:update', syncTeamScores);

  function renderDots() {
    els.dots.innerHTML = riddles.map((_, i) => {
      const cls = i === index ? 'dot current' : (i < index ? 'dot done' : 'dot');
      return `<span class="${cls}"></span>`;
    }).join('');
  }

  function renderRiddle() {
    const r = riddles[index];
    if (!r) return;
    els.counter.textContent = `Riddle ${index + 1} of ${riddles.length}`;
    els.riddleText.textContent = r.riddle;
    els.answerReveal.textContent = r.answer;
    els.answerReveal.classList.remove('show');

    revealed = false;
    lockedTeam = null;
    els.teamABtn.disabled = false;
    els.teamBBtn.disabled = false;
    els.teamABtn.classList.remove('locked-win');
    els.teamBBtn.classList.remove('locked-win');

    if (timer) timer.stop();
    timer = LiveEvent.createTimer(els.timerEl, TIMER_SECONDS, {
      onExpire: () => {
        els.teamABtn.disabled = true;
        els.teamBBtn.disabled = true;
      }
    });
    timer.start();
    renderDots();
  }

  function goTo(newIndex) {
    if (newIndex < 0 || newIndex >= riddles.length) return;
    index = newIndex;
    renderRiddle();
  }

  function next() {
    if (index < riddles.length - 1) goTo(index + 1);
  }
  function prev() {
    if (index > 0) goTo(index - 1);
  }

  function reveal() {
    if (revealed) return;
    revealed = true;
    if (timer) timer.stop();
    els.answerReveal.classList.add('show');
    els.teamABtn.disabled = true;
    els.teamBBtn.disabled = true;
  }

  function buzz(team) {
    if (lockedTeam) return;
    if (els.teamABtn.disabled && els.teamBBtn.disabled) return;
    lockedTeam = team;
    if (timer) timer.stop();
    els.teamABtn.disabled = true;
    els.teamBBtn.disabled = true;
    const winBtn = team === 'A' ? els.teamABtn : els.teamBBtn;
    winBtn.classList.add('locked-win');
    LiveEvent.addTeamPoint(team, 1);
  }

  els.teamABtn.addEventListener('click', () => buzz('A'));
  els.teamBBtn.addEventListener('click', () => buzz('B'));
  els.revealBtn.addEventListener('click', reveal);
  els.nextBtn.addEventListener('click', next);

  LiveEvent.onAction({
    advance: next,
    next,
    prev,
    reveal
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === '1') buzz('A');
    if (e.key === '2') buzz('B');
  });

  fetch('../content/clue-quest.json')
    .then((r) => r.json())
    .then((data) => {
      riddles = data;
      syncTeamScores();
      renderRiddle();
    })
    .catch((err) => {
      els.riddleText.textContent = 'Failed to load content/clue-quest.json';
      console.error(err);
    });
})();
