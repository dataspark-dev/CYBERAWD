/* Live Simulation — CXO impersonation escalating message thread (unscored). */
(function () {
  let data = null;
  let stage = 0; // 0..beats.length-1 = thread up to that beat; beats.length = hold; beats.length+1 = reveal
  const stageEl = document.getElementById('stage');

  function maxStage() {
    return data.beats.length + 1;
  }

  function renderThread(upToBeat) {
    const beats = data.beats.slice(0, upToBeat + 1);
    const msgsHtml = beats.map((beat, i) => `
      <div class="ls-msg beat-${i + 1}" style="--stagger-i:${i}">
        <div class="ls-avatar">${LiveEvent.escapeHtml(data.sender.initials)}</div>
        <div class="ls-bubble">
          <div class="ls-beat-label">${LiveEvent.escapeHtml(beat.label)}</div>
          <div class="ls-meta">
            <span class="ls-sender-name">${LiveEvent.escapeHtml(data.sender.name)} — ${LiveEvent.escapeHtml(data.sender.title)}</span>
            <span>${LiveEvent.escapeHtml(beat.timestamp)}</span>
          </div>
          <div class="ls-text">${LiveEvent.escapeHtml(beat.text)}</div>
        </div>
      </div>
    `).join('');
    stageEl.innerHTML = `<div class="ls-thread">${msgsHtml}</div>`;
  }

  function renderHold() {
    stageEl.innerHTML = `
      <div class="ls-hold">
        <h2>${LiveEvent.escapeHtml(data.holdPrompt.title)}</h2>
        <p>${LiveEvent.escapeHtml(data.holdPrompt.body)}</p>
      </div>
    `;
  }

  function renderReveal() {
    const r = data.reveal;
    const flagsHtml = r.redFlags.map((f) => `
      <div class="lr-flag">
        <i class="${f.icon}"></i>
        <h4>${LiveEvent.escapeHtml(f.label)}</h4>
        <p>${LiveEvent.escapeHtml(f.detail)}</p>
      </div>
    `).join('');
    stageEl.innerHTML = `
      <div class="ls-reveal">
        <div class="lr-title">${LiveEvent.escapeHtml(r.title)}</div>
        <div class="lr-subtitle">${LiveEvent.escapeHtml(r.subtitle)}</div>
        <div class="lr-flags">${flagsHtml}</div>
        <div class="lr-cta">${LiveEvent.escapeHtml(r.callToAction)}</div>
      </div>
    `;
  }

  function render() {
    if (stage < data.beats.length) {
      renderThread(stage);
    } else if (stage === data.beats.length) {
      renderHold();
    } else {
      renderReveal();
    }
  }

  function advance() {
    stage = Math.min(stage + 1, maxStage());
    render();
  }

  function back() {
    stage = Math.max(stage - 1, 0);
    render();
  }

  function skipToReveal() {
    stage = maxStage();
    render();
  }

  LiveEvent.onAction({
    advance,
    next: advance,
    prev: back,
    reveal: skipToReveal
  });

  fetch('../content/live-simulation.json')
    .then((r) => r.json())
    .then((json) => {
      data = json;
      render();
    })
    .catch((err) => {
      stageEl.innerHTML = '<p style="color:#fff;">Failed to load content/live-simulation.json</p>';
      console.error(err);
    });
})();
