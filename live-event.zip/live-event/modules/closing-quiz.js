/* Closing Knowledge Check — 5-question quiz -> STOP-VERIFY-REPORT recap -> final scoreboard. */
(function () {
  let data = null;
  let phase = 'quiz'; // 'quiz' | 'svr' | 'final'
  let qIndex = 0;
  let sIndex = 0;
  let revealed = false;
  let awarded = false;

  const stageEl = document.getElementById('stage');
  const phaseLabel = document.getElementById('phaseLabel');

  function letterFor(i) {
    return String.fromCharCode(65 + i);
  }

  function renderQuiz() {
    const q = data.questions[qIndex];
    phaseLabel.textContent = `Question ${qIndex + 1} of ${data.questions.length}`;
    const choicesHtml = q.choices.map((choice, i) => {
      const isCorrect = revealed && i === q.correctIndex;
      return `<div class="qz-choice ${isCorrect ? 'correct' : ''}">
        <span class="qz-letter">${letterFor(i)}</span>
        <span>${LiveEvent.escapeHtml(choice)}</span>
      </div>`;
    }).join('');

    stageEl.innerHTML = `
      <div class="qz-cluster-tag">${LiveEvent.escapeHtml(q.clusterLabel)}</div>
      <div class="qz-question">${LiveEvent.escapeHtml(q.question)}</div>
      <div class="qz-choices">${choicesHtml}</div>
      <div class="qz-explanation ${revealed ? 'show' : ''}">${LiveEvent.escapeHtml(q.explanation)}</div>
      <div class="le-btn-row" style="margin-top:26px;">
        <button class="le-btn amber lg" id="revealBtn" type="button" ${revealed ? 'disabled' : ''}><i class="fa-solid fa-eye"></i> Reveal Answer (R)</button>
        <button class="le-btn green lg" id="awardBtn" type="button" ${(!revealed || awarded) ? 'disabled' : ''}><i class="fa-solid fa-check"></i> +1 Point</button>
        <button class="le-btn primary lg" id="nextBtn" type="button"><i class="fa-solid fa-forward"></i> ${qIndex < data.questions.length - 1 ? 'Next Question' : 'Continue to Recap'}</button>
      </div>
      <div class="le-progress-dots">${data.questions.map((_, i) => `<span class="dot ${i === qIndex ? 'current' : (i < qIndex ? 'done' : '')}"></span>`).join('')}</div>
    `;
    document.getElementById('revealBtn').addEventListener('click', revealQuiz);
    document.getElementById('awardBtn').addEventListener('click', awardQuiz);
    document.getElementById('nextBtn').addEventListener('click', nextQuiz);
  }

  function revealQuiz() {
    if (revealed) return;
    revealed = true;
    renderQuiz();
  }
  function awardQuiz() {
    if (!revealed || awarded) return;
    awarded = true;
    LiveEvent.addModulePoints('closingQuiz', 1);
    renderQuiz();
  }
  function nextQuiz() {
    if (qIndex < data.questions.length - 1) {
      qIndex += 1;
      revealed = false;
      awarded = false;
      renderQuiz();
    } else {
      phase = 'svr';
      sIndex = 0;
      revealed = false;
      renderSvr();
    }
  }
  function prevQuiz() {
    if (qIndex > 0) {
      qIndex -= 1;
      revealed = false;
      awarded = false;
      renderQuiz();
    }
  }

  function renderSvr() {
    const s = data.stopVerifyReportPrompts[sIndex];
    phaseLabel.textContent = `STOP → VERIFY → REPORT · Prompt ${sIndex + 1} of ${data.stopVerifyReportPrompts.length}`;
    stageEl.innerHTML = `
      <div class="qz-cluster-tag">Call &amp; Response</div>
      <div class="svr-scenario-card">
        <div class="svr-scenario-text">${LiveEvent.escapeHtml(s.scenario)}</div>
        <div class="svr-response ${revealed ? 'show' : ''}">${LiveEvent.escapeHtml(s.idealResponse)}</div>
      </div>
      <div class="le-btn-row" style="margin-top:26px;">
        <button class="le-btn amber lg" id="revealBtn" type="button"><i class="fa-solid fa-eye"></i> Reveal Ideal Response (R)</button>
        <button class="le-btn primary lg" id="nextBtn" type="button"><i class="fa-solid fa-forward"></i> ${sIndex < data.stopVerifyReportPrompts.length - 1 ? 'Next Prompt' : 'Final Scoreboard'}</button>
      </div>
      <div class="le-progress-dots">${data.stopVerifyReportPrompts.map((_, i) => `<span class="dot ${i === sIndex ? 'current' : (i < sIndex ? 'done' : '')}"></span>`).join('')}</div>
    `;
    document.getElementById('revealBtn').addEventListener('click', revealSvr);
    document.getElementById('nextBtn').addEventListener('click', nextSvr);
  }
  function revealSvr() {
    revealed = true;
    renderSvr();
  }
  function nextSvr() {
    if (sIndex < data.stopVerifyReportPrompts.length - 1) {
      sIndex += 1;
      revealed = false;
      renderSvr();
    } else {
      phase = 'final';
      renderFinal();
    }
  }
  function prevSvr() {
    if (sIndex > 0) {
      sIndex -= 1;
      revealed = false;
      renderSvr();
    } else {
      phase = 'quiz';
      qIndex = data.questions.length - 1;
      revealed = true;
      awarded = true;
      renderQuiz();
    }
  }

  function renderFinal() {
    phaseLabel.textContent = 'Final Scoreboard';
    stageEl.innerHTML = `<div class="qz-final-board" id="finalBoard"></div>`;
    const total = LiveEvent.getTotal();
    const s = LiveEvent.getState();
    const board = document.getElementById('finalBoard');
    board.innerHTML = `
      <div class="fb-eyebrow">Session Complete</div>
      <h1>${LiveEvent.escapeHtml(s.sessionName || 'Department Score')}</h1>
      <div class="fb-total">${total}</div>
      <div class="lb-total-lbl">Final Total Points</div>
    `;
    const wrap = document.createElement('div');
    wrap.style.marginTop = '30px';
    board.appendChild(wrap);
    LiveEvent.renderLeaderboard(wrap);
  }

  function render() {
    if (phase === 'quiz') renderQuiz();
    else if (phase === 'svr') renderSvr();
    else renderFinal();
  }

  function advance() {
    if (phase === 'quiz') nextQuiz();
    else if (phase === 'svr') nextSvr();
  }
  function prev() {
    if (phase === 'quiz') prevQuiz();
    else if (phase === 'svr') prevSvr();
    else { phase = 'svr'; sIndex = data.stopVerifyReportPrompts.length - 1; revealed = true; renderSvr(); }
  }
  function reveal() {
    if (phase === 'quiz') revealQuiz();
    else if (phase === 'svr') revealSvr();
  }

  LiveEvent.onAction({ advance, next: advance, prev, reveal });

  fetch('../content/closing-quiz.json')
    .then((r) => r.json())
    .then((json) => {
      data = json;
      render();
    })
    .catch((err) => {
      stageEl.innerHTML = '<p style="color:#fff;">Failed to load content/closing-quiz.json</p>';
      console.error(err);
    });
})();
