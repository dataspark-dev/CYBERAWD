/* ============================================================
   LIVE EVENT FACILITATOR CONSOLE — shared engine
   State (scoreboard + session), keyboard-shortcut navigation,
   scoreboard widget rendering, full-screen leaderboard, and a
   reusable countdown timer used by Clue Quest & Pass-Phrase.
   ============================================================ */

const LiveEvent = (() => {
  const STORAGE_KEY = 'synergyLiveEventState_v1';

  const MODULE_META = {
    faultFinding: { label: 'Fault Finding', scored: true },
    liveSimulation: { label: 'Live Simulation', scored: false },
    clueQuest: { label: 'Cyber Clue Quest', scored: true },
    passPhrase: { label: 'Pass-Phrase', scored: true },
    closingQuiz: { label: 'Closing Quiz', scored: true }
  };

  function defaultState() {
    return {
      sessionName: '',
      teams: {
        A: { label: 'Team A', points: 0 },
        B: { label: 'Team B', points: 0 }
      },
      moduleScores: {
        faultFinding: 0,
        liveSimulation: null,
        clueQuest: 0,
        passPhrase: 0,
        closingQuiz: 0
      },
      history: [],
      pastDepartments: []
    };
  }

  let state = load();

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      const base = defaultState();
      return {
        ...base,
        ...parsed,
        teams: { ...base.teams, ...(parsed.teams || {}) },
        moduleScores: { ...base.moduleScores, ...(parsed.moduleScores || {}) },
        history: Array.isArray(parsed.history) ? parsed.history : [],
        pastDepartments: Array.isArray(parsed.pastDepartments) ? parsed.pastDepartments : []
      };
    } catch (e) {
      console.warn('LiveEvent: failed to load saved state, starting fresh.', e);
      return defaultState();
    }
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('LiveEvent: failed to persist state.', e);
    }
    document.dispatchEvent(new CustomEvent('liveevent:update', { detail: getState() }));
    renderScoreboardWidget();
  }

  function getState() {
    return JSON.parse(JSON.stringify(state));
  }

  function getTotal() {
    return Object.values(state.moduleScores).reduce((sum, v) => sum + (typeof v === 'number' ? v : 0), 0);
  }

  function setSessionName(name) {
    state.sessionName = String(name || '').trim();
    persist();
  }

  function addModulePoints(moduleKey, amount) {
    if (!(moduleKey in state.moduleScores)) return;
    if (state.moduleScores[moduleKey] === null) return;
    state.moduleScores[moduleKey] += amount;
    state.history.push({ ts: Date.now(), module: moduleKey, delta: amount });
    persist();
  }

  function addTeamPoint(teamKey, amount) {
    if (!(teamKey in state.teams)) return;
    state.teams[teamKey].points += amount;
    state.moduleScores.clueQuest = state.teams.A.points + state.teams.B.points;
    state.history.push({ ts: Date.now(), module: 'clueQuest', team: teamKey, delta: amount });
    persist();
  }

  function resetForNextDepartment() {
    const total = getTotal();
    if (state.sessionName || total > 0) {
      state.pastDepartments.push({
        name: state.sessionName || 'Unnamed Department',
        total,
        moduleScores: { ...state.moduleScores },
        teams: { A: state.teams.A.points, B: state.teams.B.points },
        ts: Date.now()
      });
      if (state.pastDepartments.length > 12) state.pastDepartments.shift();
    }
    const base = defaultState();
    state.sessionName = '';
    state.teams = base.teams;
    state.moduleScores = base.moduleScores;
    state.history = [];
    persist();
  }

  function resetScoresOnly() {
    const base = defaultState();
    state.teams = base.teams;
    state.moduleScores = base.moduleScores;
    state.history = [];
    persist();
  }

  // ---------------- Scoreboard widget (persistent corner) ----------------
  function renderScoreboardWidget() {
    const el = document.getElementById('scoreboardWidget');
    if (!el) return;
    const total = getTotal();
    const deptName = state.sessionName || 'No department set';
    el.innerHTML = `
      <div class="sw-dept" title="${escapeHtml(deptName)}">${escapeHtml(deptName)}</div>
      <div class="sw-total">${total} <span>PTS</span></div>
      <div class="sw-teams">
        <div class="sw-team"><div class="st-label">${escapeHtml(state.teams.A.label)}</div><div class="st-val">${state.teams.A.points}</div></div>
        <div class="sw-team"><div class="st-label">${escapeHtml(state.teams.B.label)}</div><div class="st-val">${state.teams.B.points}</div></div>
      </div>
    `;
  }

  // ---------------- Full-screen leaderboard ----------------
  function renderLeaderboard(container) {
    const total = getTotal();
    const deptName = state.sessionName || 'No department set';
    const moduleRows = Object.keys(MODULE_META).map((key) => {
      const meta = MODULE_META[key];
      const val = state.moduleScores[key];
      const valHtml = meta.scored
        ? `<div class="lm-val">${val}</div>`
        : `<div class="lm-val unscored">UNSCORED</div>`;
      return `<div class="lb-mod"><div class="lm-label">${escapeHtml(meta.label)}</div>${valHtml}</div>`;
    }).join('');

    const historyHtml = state.pastDepartments.length ? `
      <div class="lb-history">
        <h3>Earlier Departments Today</h3>
        ${state.pastDepartments.slice().reverse().map((d) => `
          <div class="lb-history-row">
            <span>${escapeHtml(d.name)}</span>
            <span class="hr-score">${d.total} pts</span>
          </div>
        `).join('')}
      </div>
    ` : '';

    container.innerHTML = `
      <div class="lb-eyebrow">Running Scoreboard</div>
      <h1>${escapeHtml(deptName)}</h1>
      <div class="lb-total-ring">${total}</div>
      <div class="lb-total-lbl">Total Points</div>
      <div class="lb-breakdown">${moduleRows}</div>
      <div class="lb-breakdown" style="max-width:400px;">
        <div class="lb-mod"><div class="lm-label">${escapeHtml(state.teams.A.label)} (Clue Quest)</div><div class="lm-val">${state.teams.A.points}</div></div>
        <div class="lb-mod"><div class="lm-label">${escapeHtml(state.teams.B.label)} (Clue Quest)</div><div class="lm-val">${state.teams.B.points}</div></div>
      </div>
      ${historyHtml}
    `;
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // ---------------- Keyboard navigation ----------------
  let keyHandlers = {};
  function onAction(map) {
    keyHandlers = map || {};
  }

  function isTypingTarget(el) {
    return el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
  }

  function resolveHome() {
    return document.body.dataset.home || 'index.html';
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  function initKeyboard() {
    document.addEventListener('keydown', (e) => {
      if (isTypingTarget(e.target)) return;

      switch (e.key) {
        case ' ':
        case 'Enter':
          e.preventDefault();
          (keyHandlers.advance || keyHandlers.next)?.();
          break;
        case 'r':
        case 'R':
          e.preventDefault();
          keyHandlers.reveal?.();
          break;
        case 'ArrowRight':
          e.preventDefault();
          (keyHandlers.next || keyHandlers.advance)?.();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          keyHandlers.prev?.();
          break;
        case 'ArrowUp':
          keyHandlers.up?.();
          break;
        case 'ArrowDown':
          keyHandlers.down?.();
          break;
        case 'Escape':
          if (keyHandlers.escape) {
            keyHandlers.escape();
          } else {
            window.location.href = resolveHome();
          }
          break;
        case 'f':
        case 'F':
          toggleFullscreen();
          break;
        default:
          break;
      }
    });
  }

  // ---------------- Shared countdown timer ----------------
  // createTimer(el, seconds, { onExpire, onTick }) -> { start, stop, reset, isRunning }
  function createTimer(el, totalSeconds, opts) {
    opts = opts || {};
    let remaining = totalSeconds;
    let intervalId = null;
    let expired = false;

    function render() {
      el.classList.remove('amber', 'red', 'expired');
      if (remaining <= 5 && remaining > 0) el.classList.add('red');
      else if (remaining <= 10 && remaining > 0) el.classList.add('amber');
      if (expired) el.classList.add('expired');
      const digits = el.querySelector('.lt-digits');
      if (digits) digits.textContent = String(Math.max(remaining, 0)).padStart(2, '0');
    }

    function beep() {
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.18, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
        osc.onended = () => ctx.close();
      } catch (e) {
        // Web Audio unavailable — silently skip the beep.
      }
    }

    function tick() {
      remaining -= 1;
      render();
      opts.onTick?.(remaining);
      if (remaining <= 0) {
        stop();
        expired = true;
        render();
        beep();
        opts.onExpire?.();
      }
    }

    function start() {
      stop();
      expired = false;
      render();
      intervalId = setInterval(tick, 1000);
    }

    function stop() {
      if (intervalId) clearInterval(intervalId);
      intervalId = null;
    }

    function reset(newSeconds) {
      stop();
      remaining = typeof newSeconds === 'number' ? newSeconds : totalSeconds;
      expired = false;
      render();
    }

    render();

    return {
      start,
      stop,
      reset,
      isRunning: () => intervalId !== null,
      remaining: () => remaining
    };
  }

  // ---------------- Session bootstrapping ----------------
  function initScoreboardWidget() {
    if (document.getElementById('scoreboardWidget')) {
      renderScoreboardWidget();
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_KEY) {
          state = load();
          renderScoreboardWidget();
        }
      });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    initScoreboardWidget();
    initKeyboard();
  });

  return {
    getState,
    getTotal,
    setSessionName,
    addModulePoints,
    addTeamPoint,
    resetForNextDepartment,
    resetScoresOnly,
    renderScoreboardWidget,
    renderLeaderboard,
    onAction,
    createTimer,
    toggleFullscreen,
    escapeHtml,
    MODULE_META
  };
})();
